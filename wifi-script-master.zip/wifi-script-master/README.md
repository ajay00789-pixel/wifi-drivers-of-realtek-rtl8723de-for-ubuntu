## wifi-drivers of realtek rtl8723de for ubuntu
shell script to remove old wifi drivers (not really) and install new one for  rtl8723de using lwfinger repo https://github.com/lwfinger/rtlwifi_new   
```sh
sudo +x wifi.sh
```

```sh

sudo -s
```

```sh
./wifi.sh
```

<strong><em>tested on ubuntu 18.04 </em></strong>
